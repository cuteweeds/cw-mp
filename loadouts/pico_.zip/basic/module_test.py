if __name__ == '__main__':
    empty = ""
else:
    print("hi","what's up","hellow from module")