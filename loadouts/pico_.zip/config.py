WIFI_SSID = "MrHouse2.4"
WIFI_PASSWORD = "surf ninjas"

# Add more wifi credentials here
WIFI_KEYCHAIN = {
    "MrHouse2.4" : "surf ninjas",
    "BELL875" : "EF31A1FD6F64"
    }

"""
print(WIFI_SSID, WIFI_PASSWORD)
for x in WIFI_KEYCHAIN:
    print(x,WIFI_KEYCHAIN[x])
"""

# Add successive attempts to connect to known networks
# Add SSID scanning
# Add logic to set the SSID and PASSWORD variables matching detected SSID