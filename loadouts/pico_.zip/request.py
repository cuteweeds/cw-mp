# request.py

class Request:
    def __init__(self, post_data=None):
        self.post_data = post_data